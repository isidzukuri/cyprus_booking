/** ProgressBar для формы на jQuery и CSS3 jquery.ajaxformbar.js
 *  http://biznesguide.ru/coding/178.html
 *  Copyright (c) 2011 Шамшур Иван (http://twitter.com/ivanshamshur)
 *  Dual licensed under the MIT and GPL licenses
 */
 
;(function($){
    
    $.ajaxformbar = function(e, o){
        
        this.options = $.extend({
            text: 'Сохраняю...',
            type: 'post',
    		start: 5,
            step: 20,
            limit: 40,
            startSpeed: 200,
            endSpeed: 100,
            beforeSend: function(){},
            success: function(){}
        }, o || {});
                
        this.el = $(e);        
                
        this.save_shadow = $('<div class="save_shadow"/>');
        this.save_wrap = $('<div class="save_wrap"/>');
        this.save_bar = $('<div class="save_bar">'+this.options.text+'</div>');
        this.progress_status = 0;
        this.interval = null;
      
        this.init();
    };
    

    $.ajaxformbar.prototype = {
        
        init: function(){
            
            $('body').append(
                this.save_shadow,
                this.save_wrap.append(this.save_bar)
            );
            
            this.save_bar.css('width',this.options.start+'%');
            
            var self = this;
            
            this.el.bind('submit.progressbar',function(e){
                
                e.preventDefault();
                self._send_ajax(self.el.attr('action'),self.el.serialize());
                
            });
            
        },
        
        
        _send_ajax: function(url,data){
        
            var self = this;

        	$.ajax({
                url: url,
                type: self.options.type,
                data: data,
                beforeSend: function(jqXHR, settings){
      
                    var status = self.options.beforeSend.apply(self.el,[jqXHR, settings]);
                    
                    if(status !== false) self._show();
                    
                    return status;
               },
                success: function(response, textStatus, jqXHR){

                    self.options.success.apply(self.el,[response, textStatus, jqXHR]);
               },
               complete : function(){
                
            	   self._hide();
               }
        	});
        },
        
        _show: function(){
        
            this.save_shadow.show();
            this.save_wrap.show();
            
            var self = this;
            
            self.progress_status = self.options.start;
    
            self.interval = setInterval(function(){
                
                self.progress_status += self.options.step;
                
                self.save_bar.css('width',self.progress_status+'%');
                
                if(self.progress_status >= self.options.limit){
                    
                    clearInterval(self.interval);
                }
                
            },self.options.startSpeed);
           
        },
        
        
        _hide: function(){

            var self = this;
            
            clearInterval(self.interval);
            
            self.interval = setInterval(function(){
                
                self.progress_status += self.options.step;
                self.save_bar.css('width',self.progress_status+'%');
                
                if(self.progress_status >=100){
                    
                    clearInterval(self.interval);
    
                    self.save_shadow.hide();
                    self.save_wrap.hide();
                    
                    self.progress_status = 0;
                    self.save_bar.css('width',self.progress_status+'%');
                }
                
            },self.options.endSpeed);
        }
    };
    
    $.fn.ajaxformbar = function(o){
       
        return this.each(function() {
            
            var instance = $(this).data('ajaxformbar');

            if (typeof instance == 'undefined') {

                $(this).data('ajaxformbar', new $.ajaxformbar(this, o));
            }
        });
        
    };   
    
    
})(jQuery);